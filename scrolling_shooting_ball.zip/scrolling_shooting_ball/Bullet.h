#ifndef BULLET_H
#define BULLET_H

#include "SDL.h"
#include "SDL_image.h"
#include "SDL_ttf.h"
#include <string>
#include <stdio.h>
#include <list>
#include <vector>

class bullet{

public:
	std::list<std::vector<int> *> * bullets;
	int numBullets, first;

	virtual ~bullet();

	virtual void changeX(int x, int num);

	virtual void changeY(int y, int num);

	virtual void changeXSpeed(int speed, int num);

	virtual void changeYSpeed(int speed, int num);

	virtual int getX(int num);

	virtual int getY(int num);

	virtual void bulletsMovement();

	virtual int getNumBullets();

	virtual void new_bullet(int x, int y, int xspeed, int yspeed);

	virtual void endBullet(int width, int height);

	bullet();

	bullet(int x_pos, int y_pos);

	bullet(int x_pos, int y_pos, int xspeed);

	bullet(int x_pos, int y_pos, int xspeed, int yspeed);
};

#endif