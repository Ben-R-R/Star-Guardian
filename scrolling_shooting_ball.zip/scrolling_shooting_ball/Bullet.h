#ifndef BULLET_H
#define BULLET_H

#include "SDL.h"
#include "SDL_image.h"
#include "SDL_ttf.h"
#include <string>
#include <stdio.h>
#include <list>
#include <vector>

class bullet{

public:
	std::list<std::vector<int> *> * bullets;
	int numBullets, first;

	virtual ~bullet();

	virtual void changeX(int x, int num);

	virtual void changeY(int y, int num);

	virtual void changeX_Dest(int x, int num);

	virtual void changeY_Dest(int y, int num);

	virtual void changeSpeed(int speed, int num);

	virtual int getX(int num);

	virtual int getY(int num);

	virtual void bulletsMovement();

	virtual int getNumBullets();

	virtual void new_bullet(int x, int y, int x_dest, int y_dest, int speed);

	virtual void endBullet(int width);

	bullet();

	bullet(int x_pos, int y_pos);

	bullet(int x_pos, int y_pos, int speed);

	bullet(int x_pos, int y_pos, int x_dest, int y_dest, int speed);
};

#endif