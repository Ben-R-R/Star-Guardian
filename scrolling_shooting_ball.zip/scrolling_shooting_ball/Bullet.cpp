#include "bullet.h"
#include "SDL.h"
#include "SDL_image.h"
#include "SDL_ttf.h"
#include <string>
#include <stdio.h>
#include <list>
#include <vector>

bullet::bullet()
	: numBullets(0),
	first(0)
{}

bullet::bullet(int X_pos, int Y_pos)
	: numBullets(1),
	first(0)
{
	std::vector<int> * bul_values = new std::vector<int>(4);
	(*bul_values)[0] = X_pos;
	(*bul_values)[1] = Y_pos;
	(*bul_values)[2] = 10;
	(*bul_values)[3] = 0;
	bullets = new std::list<std::vector<int> *>(1, bul_values);
}

bullet::bullet(int X_pos, int Y_pos, int XSpeed)
	: numBullets(1),
	first(0)
{
	std::vector<int> * bul_values = new std::vector<int>(4);
	(*bul_values)[0] = X_pos;
	(*bul_values)[1] = Y_pos;
	(*bul_values)[2] = XSpeed;
	(*bul_values)[3] = 0;
	bullets = new std::list<std::vector<int> *>(1, bul_values);
}

bullet::bullet(int X_pos, int Y_pos, int XSpeed, int YSpeed)
	: numBullets(1),
	first(0)
{
	std::vector<int> * bul_values = new std::vector<int>(4);
	(*bul_values)[0] = X_pos;
	(*bul_values)[1] = Y_pos;
	(*bul_values)[2] = XSpeed;
	(*bul_values)[3] = YSpeed;
	bullets = new std::list<std::vector<int> *>(1, bul_values);
}

bullet::~bullet()
{ }

void bullet::changeX(int X, int num){
	std::list<std::vector<int> *>::iterator it;
	it = bullets->begin();
	for(int i = 0;i<num;i++){
		it++;
	}
	(*(*it))[0] = X;
}

void bullet::changeY(int Y, int num){
	std::list<std::vector<int> *>::iterator it;
	it = bullets->begin();
	for(int i = 0;i<num;i++){
		it++;
	}
	(*(*it))[1] = Y;
}

void bullet::changeXSpeed(int Speed, int num){
	std::list<std::vector<int> *>::iterator it;
	it = bullets->begin();
	for(int i = 0;i<num;i++){
		it++;
	}
	(*(*it))[2] = Speed;
}

void bullet::changeYSpeed(int Speed, int num){
	std::list<std::vector<int> *>::iterator it;
	it = bullets->begin();
	for(int i = 0;i<num;i++){
		it++;
	}
	(*(*it))[3] = Speed;
}

int bullet::getX(int num){
	std::list<std::vector<int> *>::iterator it;
	it = bullets->begin();
	for(int i = 0;i<num;i++){
		it++;
	}
	return (*(*it))[0];
}

int bullet::getY(int num){
	std::list<std::vector<int> *>::iterator it;
	it = bullets->begin();
	for(int i = 0;i<num;i++){
		it++;
	}
	return (*(*it))[1];
}

void bullet::bulletsMovement(){
	if(numBullets > 0){
		int first = (*(bullets->front()))[0];
		std::list<std::vector<int> *>::iterator it;
		for(it = bullets->begin();it!=bullets->end();it++){
			(*(*it))[1] -= (*(*it))[2];
			(*(*it))[0] -= (*(*it))[3];
		}
	}
}

void bullet::new_bullet(int X, int Y, int XSpeed, int YSpeed){
	std::vector<int> * bul_values = new std::vector<int>(4);
	(*bul_values)[0] = X;
	(*bul_values)[1] = Y;
	(*bul_values)[2] = XSpeed;
	(*bul_values)[3] = YSpeed;
	if(first == 0){
		bullets = new std::list<std::vector<int> *>(1, bul_values);
		first = 1;
	}else{
		bullets->push_front(bul_values);
	}
	numBullets++;
}

void bullet::endBullet(int width, int height){
	if(numBullets > 0){
		std::list<std::vector<int> *>::iterator it;
		std::list<std::vector<int> *>::iterator first;
		it = bullets->begin();
		for(int i = 0;i<numBullets;i++){
			if((*(*it))[1] == -10 || (*(*it))[0] == 0 || (*(*it))[0] == width - 10 || (*(*it))[1] == height - 10){
				delete(*it);
				bullets->erase(it);
				numBullets--;
			}
			it++;
		}
	}
}

int bullet::getNumBullets(){
	return numBullets;
}
